var config = {
    map: {
        '*': {
            amSearchOptions: 'Tigren_Shopby/js/search-options'
        }
    }
};