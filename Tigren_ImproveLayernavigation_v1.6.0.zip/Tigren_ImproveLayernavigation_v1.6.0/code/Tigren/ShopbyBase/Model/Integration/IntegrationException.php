<?php
/**
 * @author Tigren Team
 * @copyright Copyright (c) 2019 Tigren (https://www.tigren.com)
 * @package Tigren_ShopbyBase
 */


namespace Tigren\ShopbyBase\Model\Integration;

use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Phrase;

class IntegrationException extends LocalizedException
{
    /**
     * @param Phrase|null $phrase
     * @param \Exception|null $cause
     * @param int $code
     */
    public function __construct(Phrase $phrase = null, \Exception $cause = null, $code = 0)
    {
        if ($phrase === null) {
            $phrase = new Phrase(
                'Requested Improved Navigation submodule is disabled. Only read methods is allowed.'
            );
        }

        parent::__construct($phrase, $cause);
    }
}
