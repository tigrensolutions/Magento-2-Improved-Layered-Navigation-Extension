<?php
/**
 * @author Tigren Team
 * @copyright Copyright (c) 2019 Tigren (https://www.tigren.com)
 * @package Tigren_ShopbyBrand
 */


namespace Tigren\ShopbyBrand\Controller\Adminhtml\Slider;

/**
 * Class Save
 * @package Tigren\ShopbyBrand\Controller\Adminhtml\Slider
 * @author Evgeni Obukhovsky
 */
class Save extends \Tigren\ShopbyBase\Controller\Adminhtml\Option\Save
{
    /**
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Tigren_ShopbyBrand::slider');
    }

    protected function _redirectRefer()
    {
        $this->_forward('index');
    }
}
