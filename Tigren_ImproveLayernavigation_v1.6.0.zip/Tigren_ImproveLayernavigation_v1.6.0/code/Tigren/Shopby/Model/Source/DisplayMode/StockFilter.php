<?php
/**
 * @author Tigren Team
 * @copyright Copyright (c) 2019 Tigren (https://www.tigren.com)
 * @package Tigren_Shopby
 */

namespace Tigren\Shopby\Model\Source\DisplayMode;

class StockFilter extends \Tigren\Shopby\Model\Source\DisplayMode
{
    public function showSwatchOptions()
    {
        return false;
    }

    protected function getOptions()
    {
        $options = parent::getOptions();
        unset($options[self::MODE_SLIDER]);
        unset($options[self::MODE_FROM_TO_ONLY]);
        return $options;
    }
}
