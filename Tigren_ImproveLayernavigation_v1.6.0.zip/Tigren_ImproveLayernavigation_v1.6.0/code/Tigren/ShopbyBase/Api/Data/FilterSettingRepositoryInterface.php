<?php
/**
 * @author Tigren Team
 * @copyright Copyright (c) 2019 Tigren (https://www.tigren.com)
 * @package Tigren_ShopbyBase
 */


namespace Tigren\ShopbyBase\Api\Data;

use Magento\Framework\Exception\NoSuchEntityException;

interface FilterSettingRepositoryInterface
{
    /**
     * @param int $id
     * @param null $idFieldName
     * @return FilterSettingInterface
     * @throws NoSuchEntityException
     */
    public function get($id, $idFieldName = null);

    /**
     * @param FilterSettingInterface $filterSetting
     * @return FilterSettingRepositoryInterface
     */
    public function save(FilterSettingInterface $filterSetting);
}
