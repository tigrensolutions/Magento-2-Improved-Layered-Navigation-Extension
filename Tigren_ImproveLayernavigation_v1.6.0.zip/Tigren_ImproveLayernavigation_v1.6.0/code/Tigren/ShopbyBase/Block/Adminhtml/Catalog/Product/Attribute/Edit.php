<?php
/**
 * @author Tigren Team
 * @copyright Copyright (c) 2019 Tigren (https://www.tigren.com)
 * @package Tigren_ShopbyBase
 */


namespace Tigren\ShopbyBase\Block\Adminhtml\Catalog\Product\Attribute;

/**
 * Class Edit
 * @package Tigren\ShopbyBase\Block\Adminhtml\Catalog\Product\Attribute
 */
class Edit extends \Magento\Backend\Block\Template
{
    /**
     * @var \Magento\Framework\Registry
     */
    private $coreRegistry;

    /**
     * @var \Tigren\ShopbyBase\Model\Source\DisplayMode\Proxy
     */
    private $displayModeSource;

    /**
     * @var \Tigren\ShopbyBase\Model\FilterSetting\AttributeConfig
     */
    private $attributeSettingsConfig;

    /**
     * Edit constructor.
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry $coreRegistry
     * @param \Tigren\ShopbyBase\Model\Source\DisplayMode\Proxy $displayModeSource
     * @param \Tigren\ShopbyBase\Model\FilterSetting\AttributeConfig $attributeConfig
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $coreRegistry,
        \Tigren\ShopbyBase\Model\Source\DisplayMode\Proxy $displayModeSource,
        \Tigren\ShopbyBase\Model\FilterSetting\AttributeConfig $attributeConfig,
        array $data = []
    ) {
        $this->coreRegistry = $coreRegistry;
        $this->displayModeSource = $displayModeSource;
        $this->attributeSettingsConfig = $attributeConfig;
        parent::__construct($context, $data);
    }

    /**
     * @return string
     */
    public function getFilterCode()
    {
        /** @var $attribute \Magento\Catalog\Model\ResourceModel\Eav\Attribute */
        $attribute = $this->coreRegistry->registry('entity_attribute');

        return \Tigren\ShopbyBase\Helper\FilterSetting::ATTR_PREFIX . $attribute->getAttributeCode();
    }

    /**
     * @return bool
     */
    public function canConfigureAttributeOptions()
    {
        $attribute = $this->coreRegistry->registry('entity_attribute');
        return $this->attributeSettingsConfig->canBeConfigured($attribute->getAttributeCode());
    }
}
