<?php
/**
 * @author Tigren Team
 * @copyright Copyright (c) 2019 Tigren (https://www.tigren.com)
 * @package Tigren_Shopby
 */


namespace Tigren\Shopby\Model\ResourceModel\Cms\Relation;

use Braintree\Exception;
use Magento\Framework\EntityManager\Operation\ExtensionInterface;
use Magento\Framework\Exception\NoSuchEntityException;

/**
 * Class SaveHandler
 * @package Tigren\Shopby\Model\ResourceModel\Cms\Relation
 */
class SaveHandler implements ExtensionInterface
{
    /**
     * @var \Tigren\Shopby\Api\CmsPageRepositoryInterface
     */
    protected $pageRepository;

    /**
     * @var \Tigren\Shopby\Model\Cms\PageFactory
     */
    protected $pageFactory;

    /**
     * SaveHandler constructor.
     * @param \Tigren\Shopby\Api\CmsPageRepositoryInterface $cmsPageRepository
     */
    public function __construct(
        \Tigren\Shopby\Api\CmsPageRepositoryInterface $cmsPageRepository,
        \Tigren\Shopby\Model\Cms\PageFactory $factory
    ) {
        $this->pageRepository = $cmsPageRepository;
        $this->pageFactory = $factory;
    }

    /**
     * @param object $entity
     * @param array $arguments
     * @return object
     * @throws \Exception
     */
    public function execute($entity, $arguments = [])
    {
        $settings = $entity->getData('tgshopby_settings');

        if (is_array($settings)) {
            try {
                $shopbyPage = $this->pageRepository->getByPageId($entity->getId());
            } catch (NoSuchEntityException $e) {
                $shopbyPage = $this->pageFactory->create();
            }
            $shopbyPage->setData(array_merge(['page_id' => $entity->getId()], $settings));
            $this->pageRepository->save($shopbyPage);
        }

        return $entity;
    }
}
