<?php
/**
 * @author Tigren Team
 * @copyright Copyright (c) 2019 Tigren (https://www.tigren.com)
 * @package Tigren_Shopby
 */


namespace Tigren\Shopby\Model\GroupAttr;

class DataProviderFactory implements \Tigren\ShopbyBase\Api\GroupAttributeDataFactoryProvider
{
    /**
     * Object Manager instance
     *
     * @var \Magento\Framework\ObjectManagerInterface
     */
    protected $objectManager = null;

    /**
     * Instance name to create
     *
     * @var string
     */
    protected $_instanceName = \Tigren\Shopby\Model\GroupAttr\DataProvider::class;

    public function __construct(
        \Magento\Framework\ObjectManagerInterface $objectManager
    ) {
        $this->objectManager = $objectManager;
    }

    /**
     * Wrapper for self::getInstance()
     *
     * @param array $data
     * @return \Tigren\Shopby\Model\GroupAttr\DataProvider
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function create(array $data = [])
    {
        return $this->getInstance();
    }

    /**
     * Get created class instance
     *
     * @return \Tigren\Shopby\Model\GroupAttr\DataProvider
     */
    public function getInstance()
    {
        return $this->objectManager->get($this->_instanceName);
    }
}
