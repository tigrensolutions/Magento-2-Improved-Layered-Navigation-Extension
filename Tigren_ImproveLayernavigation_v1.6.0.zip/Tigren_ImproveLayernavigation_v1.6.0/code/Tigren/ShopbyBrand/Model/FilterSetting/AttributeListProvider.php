<?php
/**
 * @author Tigren Team
 * @copyright Copyright (c) 2019 Tigren (https://www.tigren.com)
 * @package Tigren_ShopbyBrand
 */


namespace Tigren\ShopbyBrand\Model\FilterSetting;

use Tigren\ShopbyBase\Model\FilterSetting\AttributeConfig\AttributeListProvider as AttributeListProviderInterface;
use Tigren\ShopbyBrand\Helper\Data as BrandHelper;

class AttributeListProvider implements AttributeListProviderInterface
{
    /**
     * @var BrandHelper
     */
    private $helper;

    /**
     * AttributeListProvider constructor.
     * @param BrandHelper $helper
     */
    public function __construct(BrandHelper $helper)
    {
        $this->helper = $helper;
    }

    /**
     * Getting list of attribute codes, which can be configured with Tigren Attribute Settings
     * @return array
     */
    public function getAttributeList()
    {
        return [$this->helper->getBrandAttributeCode() => true];
    }
}