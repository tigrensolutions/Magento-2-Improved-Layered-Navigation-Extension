<?php
/**
 * @author Tigren Team
 * @copyright Copyright (c) 2019 Tigren (https://www.tigren.com)
 * @package Tigren_ShopbyBase
 */


namespace Tigren\ShopbyBase\Model\FilterSetting\AttributeConfig;

interface AttributeListProvider
{
    /**
     * Getting list of attribute codes, which can be configured with Tigren Attribute Settings
     * @return array
     */
    public function getAttributeList();
}
