<?php
/**
 * @author Tigren Team
 * @copyright Copyright (c) 2019 Tigren (https://www.tigren.com)
 * @package Tigren_Shopby
 */


namespace Tigren\Shopby\Model\ResourceModel\GroupAttr;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{

    protected $_idFieldName = 'group_id';

    protected function _construct()
    {
        $this->_init(\Tigren\Shopby\Model\GroupAttr::class, \Tigren\Shopby\Model\ResourceModel\GroupAttr::class);
    }

    /**
     * @param $name
     * @param $table
     * @param $field
     * @param $where
     * @return $this
     */
    public function joinField($name, $table, $field, $where)
    {
        $this->getSelect()->joinLeft(
            [$name => $this->getTable($table)],
            $name . "." . $where,
            $field
        );

        return $this;
    }

    /**
     * @return $this
     */
    public function joinOptions()
    {
        $this->joinField('aagao', 'tigren_tgshopby_group_attr_option', ['option_id'], 'group_id=main_table.group_id');

        return $this;
    }

    /**
     * @return $this
     */
    public function joinValues()
    {
        $this->joinField('aagav', 'tigren_tgshopby_group_attr_value', ['value'], 'group_id=main_table.group_id');

        return $this;
    }
}
