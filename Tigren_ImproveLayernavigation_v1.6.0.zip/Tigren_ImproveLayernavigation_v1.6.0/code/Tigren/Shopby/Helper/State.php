<?php
/**
 * @author Tigren Team
 * @copyright Copyright (c) 2019 Tigren (https://www.tigren.com)
 * @package Tigren_Shopby
 */

namespace Tigren\Shopby\Helper;

use Magento\Framework\App\Helper\Context;

class State extends \Magento\Framework\App\Helper\AbstractHelper
{
    /**
     * @var \Tigren\ShopbyBase\Api\UrlBuilderInterface
     */
    private $amUrlBuilder;

    public function __construct(Context $context, \Tigren\ShopbyBase\Api\UrlBuilderInterface $amUrlBuilder)
    {
        parent::__construct($context);
        $this->amUrlBuilder = $amUrlBuilder;
    }

    public function getCurrentUrl()
    {
        $params['_current'] = true;
        $params['_use_rewrite'] = true;
        $params['_query'] = ['_' => null, 'shopbyAjax' => null];

        $result = str_replace('&amp;', '&', $this->amUrlBuilder->getUrl('*/*/*', $params));
        return $result;
    }
}
