/**
 * @author    Tigren Team
 * @copyright Copyright (c) Tigren Ltd. ( http://www.tigren.com/ )
 * @package   Tigren_Shopby
 */

define([
    'jquery',
    'matchMedia',
    'amShopbyTopFilters',
    'mage/tabs',
    'domReady!'
], function ($, mediaCheck, amShopbyTopFilters) {
    'use strict';

    mediaCheck({
        media: '(max-width: 768px)',
        entry: function(){
            amShopbyTopFilters.moveTopFiltersToSidebar();
        },
        exit: function(){

            amShopbyTopFilters.removeTopFiltersFromSidebar();
        }
    });
});
