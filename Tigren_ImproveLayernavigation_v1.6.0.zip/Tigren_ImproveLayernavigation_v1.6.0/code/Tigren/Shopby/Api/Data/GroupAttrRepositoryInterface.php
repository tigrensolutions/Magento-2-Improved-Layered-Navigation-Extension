<?php
/**
 * @author Tigren Team
 * @copyright Copyright (c) 2019 Tigren (https://www.tigren.com)
 * @package Tigren_Shopby
 */


namespace Tigren\Shopby\Api\Data;

use Magento\Framework\Exception\NoSuchEntityException;
/**
 * Interface GroupAttrRepositoryInterface
 * @package Tigren\Shopby\Api\Data
 */
interface GroupAttrRepositoryInterface
{
    /**
     * @param int $id
     * @return GroupAttrInterface
     * @throws NoSuchEntityException
     */
    public function get($id);

    /**
     * @param GroupAttrInterface $entity
     * @return $this
     */
    public function save(GroupAttrInterface $entity);

    /**
     * @param GroupAttrInterface $entity
     * @return $this
     */
    public function delete(GroupAttrInterface $entity);
}
