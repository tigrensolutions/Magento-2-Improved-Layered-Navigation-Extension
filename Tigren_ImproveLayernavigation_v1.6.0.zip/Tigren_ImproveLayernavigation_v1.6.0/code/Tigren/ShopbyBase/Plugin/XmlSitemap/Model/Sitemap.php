<?php
/**
 * @author Tigren Team
 * @copyright Copyright (c) 2019 Tigren (https://www.tigren.com)
 * @package Tigren_ShopbyBase
 */


namespace Tigren\ShopbyBase\Plugin\XmlSitemap\Model;

use Tigren\XmlSitemap\Model\Sitemap as NativeSitemap;
use Magento\Framework\DataObjectFactory as ObjectFactory;

class Sitemap
{
    /**
     * @var ObjectFactory
     */
    private $dataObjectFactory;

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    private $scopeConfig;

    /**
     * @var \Magento\Eav\Model\Config
     */
    private $eavConfig;

    /**
     * @var \Tigren\ShopbyBase\Helper\OptionSetting
     */
    private $optionSetting;

    /**
     * @var \Tigren\ShopbyBase\Model\XmlSitemap
     */
    private $xmlSitemap;

    public function __construct(
        ObjectFactory $dataObjectFactory,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Eav\Model\Config $eavConfig,
        \Tigren\ShopbyBase\Helper\OptionSetting $optionSetting,
        \Tigren\ShopbyBase\Model\XmlSitemap $xmlSitemap
    ) {

        $this->dataObjectFactory = $dataObjectFactory;
        $this->scopeConfig = $scopeConfig;
        $this->eavConfig = $eavConfig;
        $this->optionSetting = $optionSetting;
        $this->xmlSitemap = $xmlSitemap;
    }

    public function aroundGetBrandCollection(NativeSitemap $subgect, \Closure $proceed, $storeId)
    {
        return $this->xmlSitemap->getBrandUrls($storeId);
    }
}
