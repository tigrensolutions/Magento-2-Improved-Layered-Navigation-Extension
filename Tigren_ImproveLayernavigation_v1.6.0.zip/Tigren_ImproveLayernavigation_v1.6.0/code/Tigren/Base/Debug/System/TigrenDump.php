<?php
/**
 * @author Tigren Team
 * @copyright Copyright (c) 2019 Tigren (https://www.tigren.com)
 * @package Tigren_Base
 */


namespace Tigren\Base\Debug\System;

class TigrenDump
{
    public $className = '';

    public $shortClassName = '';

    public $methods = [];

    public $properties = [];
}
