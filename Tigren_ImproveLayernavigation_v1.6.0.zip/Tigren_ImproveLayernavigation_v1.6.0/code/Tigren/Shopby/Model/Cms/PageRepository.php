<?php
/**
 * @author Tigren Team
 * @copyright Copyright (c) 2019 Tigren (https://www.tigren.com)
 * @package Tigren_Shopby
 */

namespace Tigren\Shopby\Model\Cms;

use Tigren\Shopby\Api\CmsPageRepositoryInterface;
use Magento\Framework\Exception\NoSuchEntityException;

class PageRepository implements CmsPageRepositoryInterface
{
    /**
     * @var PageFactory
     */
    protected $facory;

    /**
     * @var \Tigren\Shopby\Model\ResourceModel\Cms\Page
     */
    protected $resource;

    /**
     * PageRepository constructor.
     * @param PageFactory $factory
     * @param \Tigren\Shopby\Model\ResourceModel\Cms\Page $resource
     */
    public function __construct(
        PageFactory $factory,
        \Tigren\Shopby\Model\ResourceModel\Cms\Page $resource
    ) {
        $this->facory = $factory;
        $this->resource = $resource;
    }

    /**
     * @param int $pageId
     * @return \Tigren\Shopby\Model\Cms\Page
     * @throws NoSuchEntityException
     */
    public function get($pageId)
    {
        $page = $this->facory->create();
        $this->resource->load($page, $pageId);
        if (!$page->getId()) {
            throw new NoSuchEntityException(__('Requested page doesn\'t exist'));
        }
        return $page;
    }

    /**
     * @param int $pageId
     * @return \Tigren\Shopby\Model\Cms\Page
     * @throws NoSuchEntityException
     */
    public function getByPageId($pageId)
    {
        $page = $this->facory->create();
        $this->resource->load($page, $pageId, 'page_id');
        if (!$page->getId()) {
            throw new NoSuchEntityException(__('Requested page doesn\'t exist'));
        }
        return $page;
    }

    /**
     * @param \Tigren\Shopby\Model\Cms\Page $page
     * @return \Tigren\Shopby\Model\Cms\Page
     */
    public function save($page)
    {
        $this->resource->save($page);
        return $page;
    }
}
