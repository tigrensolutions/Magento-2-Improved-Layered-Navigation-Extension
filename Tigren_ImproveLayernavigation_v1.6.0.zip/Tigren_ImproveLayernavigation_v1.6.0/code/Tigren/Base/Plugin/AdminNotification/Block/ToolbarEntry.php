<?php
/**
 * @author Tigren Team
 * @copyright Copyright (c) 2019 Tigren (https://www.tigren.com)
 * @package Tigren_Base
 */


namespace Tigren\Base\Plugin\AdminNotification\Block;

use Magento\AdminNotification\Block\ToolbarEntry as NativeToolbarEntry;

class ToolbarEntry
{
    const TIGREN_ATTRIBUTE = ' data-tgbase-logo="1"';

    public function afterToHtml(
        NativeToolbarEntry $subject,
        $html
    ) {
        $collection = $subject->getLatestUnreadNotifications()
            ->clear()
            ->addFieldToFilter('is_tigren', 1);

        foreach ($collection as $item) {
            $search = 'data-notification-id="' . $item->getId() . '"';
            if ($item->getData('image_url')) {
                $html = str_replace(
                    $search,
                    $search . ' style="background: url(' . $item->getData('image_url') . ') no-repeat;"',
                    $html
                );
            } else {
                $html = str_replace($search, $search . self::TIGREN_ATTRIBUTE, $html);
            }
        }

        return $html;
    }
}
