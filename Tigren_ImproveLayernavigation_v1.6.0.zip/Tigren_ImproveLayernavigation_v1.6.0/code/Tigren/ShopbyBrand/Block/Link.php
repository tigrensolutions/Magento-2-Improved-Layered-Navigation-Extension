<?php
/**
 * @author Tigren Team
 * @copyright Copyright (c) 2019 Tigren (https://www.tigren.com)
 * @package Tigren_ShopbyBrand
 */


namespace Tigren\ShopbyBrand\Block;

use Magento\Store\Model\ScopeInterface;

/**
 * @api
 */
class Link extends \Magento\Framework\View\Element\Html\Link
{
    /**
     * @var \Tigren\ShopbyBrand\Helper\Data
     */
    private $helper;

    /**
     * Link constructor.
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Tigren\ShopbyBrand\Helper\Data $helper
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Tigren\ShopbyBrand\Helper\Data $helper,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->helper = $helper;
    }

    protected function _construct()
    {
        $this->setLabel((string)$this->_scopeConfig
            ->getValue('tgshopby_brand/general/menu_item_label', ScopeInterface::SCOPE_STORE));
        return parent::_construct();
    }

    /**
     * @return string
     */
    public function getHref()
    {
        return $this->helper->getAllBrandsUrl();
    }

    /**
     * @return string
     */
    protected function _toHtml()
    {
        if (!$this->isEnabled()) {
            return '';
        }
        return parent::_toHtml();
    }

    /**
     * @return bool
     */
    private function isEnabled()
    {
        return (bool) $this->_scopeConfig
            ->getValue('tgshopby_brand/general/top_links', ScopeInterface::SCOPE_STORE);
    }
}
