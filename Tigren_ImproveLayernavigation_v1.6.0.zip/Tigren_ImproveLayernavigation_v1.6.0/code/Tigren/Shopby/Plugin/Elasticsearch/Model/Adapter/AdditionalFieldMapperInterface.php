<?php
/**
 * @author Tigren Team
 * @copyright Copyright (c) 2019 Tigren (https://www.tigren.com)
 * @package Tigren_Shopby
 */


namespace Tigren\Shopby\Plugin\Elasticsearch\Model\Adapter;

/**
 * Interface AdditionalFieldMapperInterface
 * @package Tigren\Shopby\Plugin\Elasticsearch\Model\Adapter
 */
interface AdditionalFieldMapperInterface
{
    /**
     * @return array
     */
    public function getAdditionalAttributeTypes();

    /**
     * @param array $context
     * @return string
     */
    public function getFiledName($context);
}
