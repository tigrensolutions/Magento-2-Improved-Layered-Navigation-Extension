/**
 * @author    Tigren Team
 * @copyright Copyright (c) Tigren Ltd. ( http://www.tigren.com/ )
 * @package   Tigren_Shopby
 */

var config = {
    map: {
        '*': {
            amShopbyFilterAbstract: 'Tigren_Shopby/js/amShopby',
            amShopbyFilterItemDefault: 'Tigren_Shopby/js/amShopby',
            amShopbyFilterDropdown: 'Tigren_Shopby/js/amShopby',
            amShopbyFilterFromTo: 'Tigren_Shopby/js/amShopby',
            amShopbyFilterSlider: 'Tigren_Shopby/js/amShopby',
            amShopbyAjax: 'Tigren_Shopby/js/amShopbyAjax',
            amShopbyFilterSearch: 'Tigren_Shopby/js/amShopby',
            amShopbyFilterHideMoreOptions: 'Tigren_Shopby/js/amShopby',
            amShopbyFilterAddTooltip: 'Tigren_Shopby/js/amShopby',
            amShopbySwatchesChoose: 'Tigren_Shopby/js/amShopbySwatchesChoose',
            amShopbyFilterMultiselect: 'Tigren_Shopby/js/amShopby',
            amShopbyFilterSwatch: 'Tigren_Shopby/js/amShopby',
            amShopbyFiltersSync: 'Tigren_Shopby/js/amShopbyFiltersSync',
            amShopbyApplyFilters: 'Tigren_Shopby/js/amShopbyApplyFilters',
            amShopbyTopFilters: 'Tigren_Shopby/js/amShopbyTopFilters',
            amShopbyFilterCategoryDropdown: 'Tigren_Shopby/js/amShopby',
            amShopbyFilterCategoryLabelsFolding: 'Tigren_Shopby/js/amShopby',
            amShopbyFilterCategoryFlyOut: 'Tigren_Shopby/js/amShopby',
            amShopbyFilterContainer: 'Tigren_Shopby/js/amShopby'
        }
    },
    deps: [
        'Tigren_Shopby/js/amShopbyResponsive'
    ]
};
