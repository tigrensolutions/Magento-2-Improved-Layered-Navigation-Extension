<?php
/**
 * @author Tigren Team
 * @copyright Copyright (c) 2019 Tigren (https://www.tigren.com)
 * @package Tigren_Shopby
 */


namespace Tigren\Shopby\Controller\Adminhtml\Group;

class Index extends \Tigren\Shopby\Controller\Adminhtml\Group
{
    /**
     * Index action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu('Tigren_Shopby::group_attributes')
            ->addBreadcrumb(__('Manage Group Attributes'), __('Manage Group Attributes'));
        $resultPage->getConfig()->getTitle()->prepend(__('Manage Group Attributes'));
        return $resultPage;
    }

    /**
     * {@inheritdoc}
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Tigren_Shopby::group_attributes');
    }
}
