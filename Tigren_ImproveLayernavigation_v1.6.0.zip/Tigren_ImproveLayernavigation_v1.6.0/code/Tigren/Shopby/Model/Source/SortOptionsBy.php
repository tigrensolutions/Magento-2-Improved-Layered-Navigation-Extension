<?php
/**
 * @author Tigren Team
 * @copyright Copyright (c) 2019 Tigren (https://www.tigren.com)
 * @package Tigren_Shopby
 */


namespace Tigren\Shopby\Model\Source;

class SortOptionsBy implements \Magento\Framework\Option\ArrayInterface
{
    const POSITION = 0;
    const NAME = 1;

    public function toOptionArray()
    {
        return [
            [
                'value' => self::POSITION,
                'label' => __('Position')
            ],
            [
                'value' => self::NAME,
                'label' => __('Name')
            ],
        ];
    }
}
