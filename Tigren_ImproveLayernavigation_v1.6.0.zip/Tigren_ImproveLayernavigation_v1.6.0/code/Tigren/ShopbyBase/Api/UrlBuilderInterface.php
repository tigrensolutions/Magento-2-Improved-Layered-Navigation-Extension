<?php
/**
 * @author Tigren Team
 * @copyright Copyright (c) 2019 Tigren (https://www.tigren.com)
 * @package Tigren_ShopbyBase
 */


namespace Tigren\ShopbyBase\Api;

interface UrlBuilderInterface
{
    /**
     * @param null $routePath
     * @param null $routeParams
     * @return string
     */
    public function getUrl($routePath = null, $routeParams = null);

    /**
     * @param bool $modified = true
     * @return string
     */
    public function getCurrentUrl($modified = true);
}
