<?php
/**
 * @author Tigren Team
 * @copyright Copyright (c) 2019 Tigren (https://www.tigren.com)
 * @package Tigren_ShopbyBase
 */


namespace Tigren\ShopbyBase\Model\Integration;

use Tigren\ShopbyBase\Model\Integration\IntegrationException;

class DummyObject
{
    /**
     * @param string $method
     * @param array $args
     * @return null
     * @throws IntegrationException
     */
    public function __call($method, $args)
    {
        if (substr($method, 0, 3) === 'get') {
            return null;
        }

        throw new IntegrationException();
    }
}
