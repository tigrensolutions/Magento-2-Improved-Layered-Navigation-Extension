<?php
/**
 * @author Tigren Team
 * @copyright Copyright (c) 2019 Tigren (https://www.tigren.com)
 * @package Tigren_ShopbyBase
 */


namespace Tigren\ShopbyBase\Model\ResourceModel\FilterSetting;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * Collection protected constructor
     */
    protected function _construct()
    {
        $this->_init(
            \Tigren\ShopbyBase\Model\FilterSetting::class,
            \Tigren\ShopbyBase\Model\ResourceModel\FilterSetting::class
        );
    }
}
