<?php
/**
 * @author Tigren Team
 * @copyright Copyright (c) 2019 Tigren (https://www.tigren.com)
 * @package Tigren_Shopby
 */


namespace Tigren\Shopby\Model\Source\FilterDataPosition;

use Tigren\Shopby\Model\Source;

class Description extends Source\AbstractFilterDataPosition implements \Magento\Framework\Option\ArrayInterface
{
    protected function _setLabel()
    {
        $this->_label = __('Category Description');
    }
}
