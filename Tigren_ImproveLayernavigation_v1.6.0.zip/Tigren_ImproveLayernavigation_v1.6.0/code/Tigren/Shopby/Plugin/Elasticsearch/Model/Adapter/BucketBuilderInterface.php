<?php
/**
 * @author Tigren Team
 * @copyright Copyright (c) 2019 Tigren (https://www.tigren.com)
 * @package Tigren_Shopby
 */


namespace Tigren\Shopby\Plugin\Elasticsearch\Model\Adapter;

use Magento\Framework\Search\Request\BucketInterface as RequestBucketInterface;

interface BucketBuilderInterface
{
    /**
     * @param RequestBucketInterface $bucket
     * @param array $queryResult
     * @return array
     */
    public function build(
        RequestBucketInterface $bucket,
        array $queryResult
    );
}
