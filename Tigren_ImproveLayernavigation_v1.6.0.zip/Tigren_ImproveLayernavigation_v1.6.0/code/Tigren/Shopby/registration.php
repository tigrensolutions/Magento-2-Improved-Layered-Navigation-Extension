<?php
/**
 * @author Tigren Team
 * @copyright Copyright (c) 2019 Tigren (https://www.tigren.com)
 * @package Tigren_Shopby
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Tigren_Shopby',
    __DIR__
);
