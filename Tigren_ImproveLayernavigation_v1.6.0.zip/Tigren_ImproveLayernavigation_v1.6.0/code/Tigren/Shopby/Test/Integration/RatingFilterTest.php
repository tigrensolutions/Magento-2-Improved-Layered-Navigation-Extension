<?php
/**
 * @author Tigren Team
 * @copyright Copyright (c) 2019 Tigren (https://www.tigren.com)
 * @package Tigren_Shopby
 */

// @codingStandardsIgnoreFile

namespace Tigren\Shopby\Test\Integration;

use Magento\TestFramework\TestCase\AbstractController;

class RatingFilterTest extends AbstractController
{
    /**
     * @magentoConfigFixture current_store tgshopby/rating_filter/enabled 1
     * @magentoConfigFixture current_store tgshopby_root/general/enabled 1
     */
    public function testRatingFilter()
    {
        $this->dispatch('tgshopby/index/index');
        $body = $this->getResponse()->getBody();
        $message = 'rating filter not found on all-products page';
        $this->assertContains('tg-filter-items-rating', $body, $message);
        $this->assertContains('data-tgshopby-filter="rating"', $body, $message);
    }
}

