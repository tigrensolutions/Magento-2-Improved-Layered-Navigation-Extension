<?php
/**
 * @author Tigren Team
 * @copyright Copyright (c) 2019 Tigren (https://www.tigren.com)
 * @package Tigren_Shopby
 */


namespace Tigren\Shopby\Plugin\Framework\Search\Request\Config;

class FilesystemReader
{
    /**
     * @var \Tigren\Shopby\Model\Search\RequestGenerator
     */
    protected $requestGenerator;

    /**
     * ReaderPlugin constructor.
     *
     * @param \Tigren\Shopby\Model\Search\RequestGenerator $requestGenerator
     */
    public function __construct(
        \Tigren\Shopby\Model\Search\RequestGenerator $requestGenerator
    ) {
        $this->requestGenerator = $requestGenerator;
    }

    /**
     * @param \Magento\Framework\Config\ReaderInterface $subject
     * @param array $requests
     * @return array
     * @SuppressWarnings(PHPMD.UnusedFormatParameter)
     */
    public function afterRead(\Magento\Framework\Config\ReaderInterface $subject, $requests)
    {
        return array_merge_recursive($requests, $this->requestGenerator->generate());
    }
}
