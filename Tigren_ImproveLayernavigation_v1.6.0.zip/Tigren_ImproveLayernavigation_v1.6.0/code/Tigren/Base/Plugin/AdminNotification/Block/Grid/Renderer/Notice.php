<?php
/**
 * @author Tigren Team
 * @copyright Copyright (c) 2019 Tigren (https://www.tigren.com)
 * @package Tigren_Base
 */


namespace Tigren\Base\Plugin\AdminNotification\Block\Grid\Renderer;

use Magento\AdminNotification\Block\Grid\Renderer\Notice as NativeNotice;

class Notice
{
    public function aroundRender(
        NativeNotice $subject,
        \Closure $proceed,
        \Magento\Framework\DataObject $row
    ) {
        $result = $proceed($row);

        $tigrenLogo = '';
        $tigrenImage = '';
        if ($row->getData('is_tigren')) {
            if ($row->getData('image_url')) {
                $tigrenImage = ' style="background: url(' . $row->getData("image_url") . ') no-repeat;"';
            } else {
                $tigrenLogo = ' tigren-grid-logo';
            }
        }
        $result = '<div class="tgbase-grid-message' . $tigrenLogo . '"' . $tigrenImage . '>' . $result . '</div>';

        return  $result;
    }
}
