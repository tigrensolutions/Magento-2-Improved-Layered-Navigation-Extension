<?php
/**
 * @author Tigren Team
 * @copyright Copyright (c) 2019 Tigren (https://www.tigren.com)
 * @package Tigren_Shopby
 */


namespace Tigren\Shopby\Model\ResourceModel;

use Tigren\Shopby\Api\GroupRepositoryInterface;

class GroupRepository implements GroupRepositoryInterface
{
    protected $groupAttr;

    public function __construct(
        \Tigren\Shopby\Model\ResourceModel\GroupAttr $groupAttr
    ) {
        $this->groupAttr = $groupAttr;
    }

    /**
     * @param $groupCode
     * @return array|false
     */
    public function getGroupOptionsIds($groupCode)
    {
        $select = $this->groupAttr->getConnection()->select()->from(
            ['group' => $this->groupAttr->getTable('tigren_tgshopby_group_attr')],
            ''
        )->where('group.group_code = ?', $groupCode);
        $select->joinLeft(
            ['option' => $this->groupAttr->getTable('tigren_tgshopby_group_attr_option')],
            'option.group_id=group.group_id',
            ['option.option_id']
        );
        return $this->groupAttr->getConnection()->fetchCol($select);
    }
}
