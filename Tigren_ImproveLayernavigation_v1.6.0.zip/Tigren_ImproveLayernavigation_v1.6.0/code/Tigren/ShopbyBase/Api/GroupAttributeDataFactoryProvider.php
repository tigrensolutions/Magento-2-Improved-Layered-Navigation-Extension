<?php
/**
 * @author Tigren Team
 * @copyright Copyright (c) 2019 Tigren (https://www.tigren.com)
 * @package Tigren_ShopbyBase
 */


namespace Tigren\ShopbyBase\Api;

interface GroupAttributeDataFactoryProvider
{
    /**
     * @param array $data
     * @return mixed
     */
    public function create(array $data = []);
}
