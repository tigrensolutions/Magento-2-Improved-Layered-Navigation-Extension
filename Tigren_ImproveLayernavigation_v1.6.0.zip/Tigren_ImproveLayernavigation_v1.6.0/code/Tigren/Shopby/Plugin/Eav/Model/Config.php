<?php
/**
 * @author Tigren Team
 * @copyright Copyright (c) 2019 Tigren (https://www.tigren.com)
 * @package Tigren_Shopby
 */


namespace Tigren\Shopby\Plugin\Eav\Model;

use Magento\Eav\Model\Entity\Attribute\AbstractAttribute;

class Config
{
    /**
     * @param \Magento\Eav\Model\Config $subject
     * @param \Closure $closure
     * @param mixed $entityType
     * @param mixed $code
     * @return AbstractAttribute
     * @SuppressWarnings(PHPMD.UnusedFormatParameter)
     */
    public function aroundGetAttribute(\Magento\Eav\Model\Config $subject, \Closure $closure, $entityType, $code)
    {
        if (is_string($code) &&
            ($pos = strpos($code, \Tigren\Shopby\Model\Search\RequestGenerator::FAKE_SUFFIX)) !== false) {
            $code = substr($code, 0, $pos);
        }
        return $closure($entityType, $code);
    }
}
