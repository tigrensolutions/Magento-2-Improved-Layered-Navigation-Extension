<?php
/**
 * @author Tigren Team
 * @copyright Copyright (c) 2019 Tigren (https://www.tigren.com)
 * @package Tigren_Shopby
 */


$objectManager = \Magento\TestFramework\Helper\Bootstrap::getObjectManager();
/** @var \Tigren\ShopbyBase\Helper\FilterSetting $baseHelper */
$baseHelper = $objectManager->get(\Tigren\ShopbyBase\Helper\FilterSetting::class);
/** @var \Tigren\ShopbyBase\Model\FilterSetting $setting */
$setting =  $baseHelper->getSettingByAttributeCode('material');
$setting->setIsMultiselect(true);
$setting->setIsUseAndLogic(true);
$setting->save();
