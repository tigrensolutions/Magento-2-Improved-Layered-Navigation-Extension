<?php
/**
 * @author Tigren Team
 * @copyright Copyright (c) 2019 Tigren (https://www.tigren.com)
 * @package Tigren_Shopby
 */


namespace Tigren\Shopby\Model\ResourceModel\GroupAttrValue;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    protected $_idFieldName = 'group_option_id';

    protected function _construct()
    {
        $this->_init(
            \Tigren\Shopby\Model\GroupAttrValue::class,
            \Tigren\Shopby\Model\ResourceModel\GroupAttrValue::class
        );
    }
}
