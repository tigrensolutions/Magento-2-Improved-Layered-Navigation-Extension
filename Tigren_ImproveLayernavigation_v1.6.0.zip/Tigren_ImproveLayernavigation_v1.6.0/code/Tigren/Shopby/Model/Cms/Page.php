<?php
/**
 * @author Tigren Team
 * @copyright Copyright (c) 2019 Tigren (https://www.tigren.com)
 * @package Tigren_Shopby
 */

namespace Tigren\Shopby\Model\Cms;

class Page extends \Magento\Framework\Model\AbstractModel
{
    const VAR_SETTINGS = 'tgshopby_settings';

    protected function _construct()
    {
        $this->_init(\Tigren\Shopby\Model\ResourceModel\Cms\Page::class);
    }
}
