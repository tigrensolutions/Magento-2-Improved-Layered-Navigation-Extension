<?php
/**
 * @author Tigren Team
 * @copyright Copyright (c) 2019 Tigren (https://www.tigren.com)
 * @package Tigren_ShopbyBrand
 */


namespace Tigren\ShopbyBrand\Controller;

/**
 * Class RegistryConstants
 * @package Tigren\ShopbyBrand\Controller
 * @author Evgeni Obukhovsky
 */
class RegistryConstants
{
    const FEATURED = 'tigren_shopbybrand_featured';
}
