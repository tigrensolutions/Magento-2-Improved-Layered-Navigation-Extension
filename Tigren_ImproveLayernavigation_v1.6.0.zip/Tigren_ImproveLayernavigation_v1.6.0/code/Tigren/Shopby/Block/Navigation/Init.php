<?php
/**
 * @author Tigren Team
 * @copyright Copyright (c) 2019 Tigren (https://www.tigren.com)
 * @package Tigren_Shopby
 */

namespace Tigren\Shopby\Block\Navigation;

use Magento\Framework\View\Element\Template;

/**
 * @api
 */
class Init extends \Magento\Framework\View\Element\Template
{
    public function __construct(
        Template\Context $context,
        \Tigren\ShopbyBase\Model\Category\Manager\Proxy $categoryManager,
        array $data = []
    ) {
        $categoryManager->init();
        return parent::__construct($context, $data);
    }
}
