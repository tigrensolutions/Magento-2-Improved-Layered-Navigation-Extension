var config = {
    config: {
        mixins: {
            'js/theme': {
                'Tigren_Base/js/theme': true
            }
        }
    }
};
