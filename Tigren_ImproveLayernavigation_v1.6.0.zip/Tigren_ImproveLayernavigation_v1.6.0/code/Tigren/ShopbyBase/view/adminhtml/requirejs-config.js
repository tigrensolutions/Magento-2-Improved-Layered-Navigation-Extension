var config = {
    map: {
        '*': {
            optionsContent: 'Tigren_ShopbyBase/js/options-content',
            chosen: 'Tigren_ShopbyBase/js/chosen/chosen.jquery'
        }
    }
};
