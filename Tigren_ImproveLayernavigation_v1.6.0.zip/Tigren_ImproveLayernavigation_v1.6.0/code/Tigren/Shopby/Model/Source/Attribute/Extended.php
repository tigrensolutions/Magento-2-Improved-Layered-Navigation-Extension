<?php
/**
 * @author Tigren Team
 * @copyright Copyright (c) 2019 Tigren (https://www.tigren.com)
 * @package Tigren_Shopby
 */

namespace Tigren\Shopby\Model\Source\Attribute;

class Extended extends \Tigren\Shopby\Model\Source\Attribute
{
    const ALL = 'tgshopby_all_attributes';

    /**
     * Options getter
     *
     * @return array
     */
    public function toOptionArray($boolean = 1)
    {
        $allOption = [[
            'value' => self::ALL,
            'label' => (string)(__('All Attributes'))
        ]];
        return array_merge($allOption, parent::toOptionArray());
    }
}
