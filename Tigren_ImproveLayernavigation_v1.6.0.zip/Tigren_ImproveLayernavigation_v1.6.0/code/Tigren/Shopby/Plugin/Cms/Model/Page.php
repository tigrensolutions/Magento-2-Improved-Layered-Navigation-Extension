<?php
/**
 * @author Tigren Team
 * @copyright Copyright (c) 2019 Tigren (https://www.tigren.com)
 * @package Tigren_Shopby
 */


namespace Tigren\Shopby\Plugin\Cms\Model;

use Magento\Framework\Exception\NoSuchEntityException;
use Tigren\Shopby\Model\Cms\Page as TigrenCmsPage;

class Page
{
    /**
     * @var \Tigren\Shopby\Model\Cms\PageFactory
     */
    private $pageFactory;

    /**
     * @var \Tigren\Shopby\Api\CmsPageRepositoryInterface
     */
    private $pageRepository;

    /**
     * @var array
     */
    private $pageData = [];

    /**
     * Page constructor.
     * @param \Tigren\Shopby\Model\Cms\PageFactory $pageFactory
     * @param \Tigren\Shopby\Api\CmsPageRepositoryInterface $cmsPageRepository
     */
    public function __construct(
        \Tigren\Shopby\Model\Cms\PageFactory $pageFactory,
        \Tigren\Shopby\Api\CmsPageRepositoryInterface $cmsPageRepository
    ) {
        $this->pageFactory = $pageFactory;
        $this->pageRepository = $cmsPageRepository;
    }

    /**
     * @param \Magento\Cms\Model\Page $page
     * @param \Closure $proceed
     * @param string $key
     * @param null $index
     * @return mixed
     */
    public function aroundGetData(
        \Magento\Cms\Model\Page $page,
        \Closure $proceed,
        $key = '',
        $index = null
    ) {
        $data = $proceed($key, $index);
        if ($this->isAddTigrenPageData($page, $key, $data)) {
            $data[TigrenCmsPage::VAR_SETTINGS] = $this->getTigrenPageData($page->getId());
        }

        return $data;
    }

    /**
     * @param \Magento\Cms\Model\Page $page
     * @param string $key
     * @param mixed $data
     * @return bool
     */
    private function isAddTigrenPageData(\Magento\Cms\Model\Page $page, $key, $data)
    {
        $isPageDataNeeded = $key === '' || $key === TigrenCmsPage::VAR_SETTINGS;
        $isFirstCall = !(is_array($data) && array_key_exists(TigrenCmsPage::VAR_SETTINGS, $data));
        return $isPageDataNeeded && $isFirstCall && $page->getId();

    }

    /**
     * @param int $pageId
     * @return array
     */
    private function getTigrenPageData($pageId)
    {
        if (!array_key_exists($pageId, $this->pageData)) {
            $this->pageData[$pageId] = [];
            try {
                $shopbyPage = $this->pageRepository->getByPageId($pageId);
                if ($shopbyPage->getId()) {
                    $this->pageData[$pageId] = $shopbyPage->getData();
                }
            } catch (NoSuchEntityException $e) {
                //skip
            }
        }

        return $this->pageData[$pageId];
    }

    /**
     * @param \Magento\Cms\Model\Page $page
     * @param \Magento\Cms\Model\Page $returnPage
     * @return \Magento\Cms\Model\Page
     */
    public function afterSave(
        \Magento\Cms\Model\Page $page,
        \Magento\Cms\Model\Page $returnPage
    ) {
        $settings = $returnPage->getData();
        if (isset($settings[TigrenCmsPage::VAR_SETTINGS]) && is_array($settings[TigrenCmsPage::VAR_SETTINGS])) {
            try {
                $shopbyPage = $this->pageRepository->getByPageId($page->getId());
            } catch (NoSuchEntityException $e) {
                $shopbyPage = $this->pageFactory->create();
            }
            $shopbyPage->setData(array_merge(['page_id' => $page->getId()], $settings[TigrenCmsPage::VAR_SETTINGS]));
            $this->pageRepository->save($shopbyPage);
        }

        return $returnPage;
    }
}
